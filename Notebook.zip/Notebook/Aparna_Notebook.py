#!/usr/bin/env python
# coding: utf-8

# In[44]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import sqlite3


# In[45]:


get_ipython().system('pip install ipython-sql')
get_ipython().system('pip install folium geopandas')


# In[46]:


pd.set_option('display.max.rows',None,'display.max_columns', None)


# In[47]:


cnn=sqlite3.connect('TRACCC.db')


# In[48]:


data.to_sql('GRID_PERPS_ISIS_ALQAIDA',cnn)


# In[49]:


get_ipython().run_line_magic('load_ext', 'sql')


# In[50]:


get_ipython().run_line_magic('sql', 'sqlite:///tracc.db')


# In[51]:


data=pd.read_csv("C:/Users/17036/Downloads/GRID_PERPS_ISIS_ALQAIDA.csv")


# In[52]:


data.head()


# In[11]:


#COUNTRY WISE ANALYSIS
country_count = get_ipython().run_line_magic('sql', 'select affiliated_organization,incident_year,country_genc_txt,count(country_genc_txt) as incident_count from DAEN690_FINALDS group by affiliated_organization,incident_year,country_genc_txt  order by incident_year asc,affiliated_organization,incident_count desc;  ')
total_query= "select affiliated_organization,incident_year,country_genc_txt,count(country_genc_txt) as incident_count from DAEN690_FINALDS group by affiliated_organization,incident_year,country_genc_txt  order by incident_year asc,affiliated_organization,incident_count desc;"
country_query=pd.read_sql_query(total_query,cnn)
country_query.head()


# In[10]:


#REGIONAL ANALYSIS
total_region = get_ipython().run_line_magic('sql', 'select affiliated_organization,incident_year,region_txt, count(region_txt) as incident_count  from DAEN690_FINALDS group by affiliated_organization,incident_year,region_txt  order by incident_year,affiliated_organization,incident_count desc;')
total_query= "select affiliated_organization,incident_year,region_txt, count(region_txt) as incident_count from DAEN690_FINALDS group by affiliated_organization,incident_year,region_txt order by incident_year,affiliated_organization,incident_count desc;"
total_region_query=pd.read_sql_query(total_query,cnn)
total_region_query.head()


# In[10]:


#KILLED,WOUNDED AND KIDNAPPED
casuality_count = get_ipython().run_line_magic('sql', 'select affiliated_organization, sum(num_killed) as Killed,sum(num_wounded) as Wounded , sum(num_hostkid) as Kidnapped from GRID_PERPS_ISIS_ALQAIDA group by affiliated_organization order by affiliated_organization; ')
total_query= "select affiliated_organization, sum(num_killed) as Killed,sum(num_wounded) as Wounded , sum(num_hostkid) as Kidnapped from GRID_PERPS_ISIS_ALQAIDA group by affiliated_organization order by affiliated_organization;"
casuality_query=pd.read_sql_query(total_query,cnn)
casuality_query.head()


# In[93]:


casuality_query = pd.read_sql_query(total_query, cnn)

# Set the aesthetic style of the plots with a beautiful background
sns.set_theme(style="darkgrid")

# Set a custom color palette
palette = sns.color_palette("husl", 3)  # 'husl' is a hue-saturation-lightness palette

# Initialize the matplotlib figure
f, ax = plt.subplots(figsize=(12, 8))

# Plot the Killed, Wounded, and Kidnapped bars on top of each other
bottom_wounded = casuality_query['Killed']
bottom_kidnapped = bottom_wounded + casuality_query['Wounded']

sns.barplot(x='affiliated_organization', y='Killed', data=casuality_query, label='Killed', color=palette[0], edgecolor='w')
sns.barplot(x='affiliated_organization', y='Wounded', data=casuality_query, label='Wounded', color=palette[1], bottom=bottom_wounded, edgecolor='w')
sns.barplot(x='affiliated_organization', y='Kidnapped', data=casuality_query, label='Kidnapped', color=palette[2], bottom=bottom_kidnapped, edgecolor='w')

# Add a legend and informative axis label
ax.legend(ncol=3, loc="upper right", frameon=True)
ax.set(xlim=(-0.5, len(casuality_query)-0.5), ylabel="",
       xlabel="Affiliated Organizations")

# Add a meaningful title
ax.set_title('Casualties by Affiliated Organization(2018-2022)', fontsize=18, weight='bold')

# Rotate the x-axis labels for better readability
plt.xticks(rotation=0, ha='right')

# Add labels on the bars
for bar in ax.patches:
    height = bar.get_height()
    if height > 0:
        ax.annotate(f'{int(height)}',
                    xy=(bar.get_x() + bar.get_width() / 2, bar.get_y() + height / 2),
                    xytext=(0, 3),  # 3 points vertical offset
                    textcoords="offset points",
                    ha='center', va='bottom', color='black', fontsize=12,weight='bold')

# Remove the top and right spines for a cleaner look
sns.despine(left=True, bottom=True)

# Show the plot with a tight layout
plt.tight_layout()
plt.show()


# In[ ]:





# In[56]:


#FACILITIES TARGETED
#facility_count= %sql SELECT affiliated_organization,SUM(facility_lvl1_co) AS Commercial,SUM(facility_lvl1_cu) AS Culture,SUM(facility_lvl1_go) AS Government,SUM(facility_lvl1_in) AS Infrastructure,SUM(facility_lvl1_mi) AS Military FROM GRID_PERPS_ISIS_ALQAIDA GROUP BY affiliated_organization;
total_query= "SELECT affiliated_organization,SUM(facility_lvl1_co) AS Commercial,SUM(facility_lvl1_cu) AS Culture,SUM(facility_lvl1_go) AS Government,SUM(facility_lvl1_in) AS Infrastructure,SUM(facility_lvl1_mi) AS Military FROM GRID_PERPS_ISIS_ALQAIDA GROUP BY affiliated_organization;"
facility_query=pd.read_sql_query(total_query,cnn)
facility_query.head()


# In[57]:


import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# I'm assuming 'total_query' and 'cnn' are defined earlier in your code.
facility_query = pd.read_sql_query(total_query, cnn)

# Melt the DataFrame for use with seaborn's barplot
# Ensure that 'affiliated_organization' and the column names for facility counts are correctly specified
facility_melted = facility_query.melt(id_vars=['affiliated_organization'], var_name='Facility Type', value_name='Count')

# Set the aesthetic style of the plots
sns.set_theme(style="darkgrid")

# Initialize the matplotlib figure
f, ax = plt.subplots(figsize=(12, 6))

# Create the barplot
# Make sure 'Facility Count', 'Affiliated organization', and 'Facility Type' match your DataFrame's column names
bar = sns.barplot(x="Count", y="affiliated_organization", hue="Facility Type", data=facility_melted, ax=ax)

# Add the legend outside the plot
plt.legend(title='Facility Type', bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)

# Loop over the bars and add text annotation
for p in bar.patches:
    width = p.get_width()  # get the width of each bar
    x, y = p.get_xy()  # get the bottom left coordinates
    if width > 0:
        bar.annotate(f'{int(width)}',  # The label for this bar
                     (x + width, y + p.get_height() / 2),  # The X and Y location of the label
                     ha='left',  # Center the label horizontally
                     va='center',  # Center the label vertically
                     weight='bold') 

# Set the title of the plot
ax.set_title('Targeted Facility Counts by Affiliated Organizations (2018-2022)', fontsize=16, weight='bold')

# Show the plot
plt.tight_layout()
plt.show()


# In[58]:


import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Assuming 'total_query' and 'cnn' are defined earlier in your code.
facility_query = pd.read_sql_query(total_query, cnn)

# Melt the DataFrame for use with seaborn's barplot
facility_melted = facility_query.melt(id_vars=['affiliated_organization'], var_name='Facility Type', value_name='Count')

# Set the aesthetic style of the plots
sns.set_theme(style="darkgrid")

# Initialize the matplotlib figure
f, ax = plt.subplots(figsize=(12, 6))

# Create the barplot with switched axes
bar = sns.barplot(y="Count", x="affiliated_organization", hue="Facility Type", data=facility_melted, ax=ax)

# Add the legend outside the plot
plt.legend(title='Facility Type', bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)

# Loop over the bars and add text annotation
for p in bar.patches:
    height = p.get_height()  # get the height of each bar
    x, y = p.get_xy()  # get the bottom left coordinates
    if height > 0:
        bar.annotate(f'{int(height)}',  # The label for this bar
                     (p.get_x() + p.get_width() / 2, y + height),  # The X and Y location of the label
                     ha='center',  # Center the label horizontally
                     va='bottom',  # Position the label at the bottom vertically
                     weight='bold') 

# Set the labels and title of the plot
ax.set_xlabel('Affiliated Organization', fontsize=12)
ax.set_ylabel('Facility Count', fontsize=12)
ax.set_title('Targeted Facility Counts by Affiliated Organizations (2018-2022)', fontsize=16, weight='bold')

# Show the plot
plt.tight_layout()
plt.show()


# In[ ]:





# In[59]:


#MOST COMMON TARGETS VICTIMS
#victim_count= %sql SELECT affiliated_organization,SUM(victim_lvl1_ci) AS Civilian Groups,SUM(victim_lvl1_go) AS Government,SUM(victim_lvl1_gp) AS Civilians,SUM(victim_lvl1_mi) AS Military,SUM(victim_lvl1_po) AS Political,SUM(victim_lvl1_pr) AS Professions FROM GRID_PERPS_ISIS_ALQAIDA GROUP BY affiliated_organization;
total_query= "SELECT affiliated_organization,SUM(victim_lvl1_ci) AS CivilianGroups,SUM(victim_lvl1_go) AS Government,SUM(victim_lvl1_gp) AS Civilians,SUM(victim_lvl1_mi) AS Military,SUM(victim_lvl1_po) AS Political,SUM(victim_lvl1_pr) AS Professions FROM GRID_PERPS_ISIS_ALQAIDA GROUP BY affiliated_organization;"
victim_query=pd.read_sql_query(total_query,cnn)
victim_query.head()


# In[55]:


import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Assuming 'total_query' and 'cnn' are defined earlier in your code.
victim_query = pd.read_sql_query(total_query, cnn)

# Melt the DataFrame for use with seaborn's barplot
victim_melted = victim_query.melt(id_vars=['affiliated_organization'], 
                                  var_name='Victim Type', 
                                  value_name='Count')

# Set the aesthetic style of the plots
sns.set_theme(style="darkgrid")

# Initialize the matplotlib figure
f, ax = plt.subplots(figsize=(12, 6))

# Create the barplot with switched axes
bar = sns.barplot(x="affiliated_organization", y="Count", hue="Victim Type", data=victim_melted, ax=ax)

# Add the legend outside the plot
plt.legend(title='Victim Type', bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)

# Loop over the bars and add text annotation
for p in bar.patches:
    height = p.get_height()  # get the height of each bar
    x, y = p.get_xy()  # get the bottom left coordinates
    if height > 0:
        bar.annotate(f'{int(height)}',  # The label for this bar
                     (x + p.get_width() / 2, y + height),  # The X and Y location of the label
                     ha='center',  # Center the label horizontally
                     va='bottom',  # Align the label to the bottom
                     weight='bold') 

# Set the labels and title of the plot
ax.set_xlabel('Affiliated Organization', fontsize=12)
ax.set_ylabel('Victim Count', fontsize=12)
ax.set_title('Victim Counts by Affiliated Organizations (2018-2022)', fontsize=16, weight='bold')

# Show the plot
plt.tight_layout()
plt.show()


# In[22]:


import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Assuming 'total_query' and 'cnn' are defined earlier in your code.
victim_query = pd.read_sql_query(total_query, cnn)

# Melt the DataFrame for use with seaborn's barplot
victim_melted = victim_query.melt(id_vars=['affiliated_organization'], 
                                  var_name='Victim Type', 
                                  value_name='Count')

# Set the aesthetic style of the plots
sns.set_theme(style="darkgrid")

# Initialize the matplotlib figure
f, ax = plt.subplots(figsize=(12, 6))

# Create the barplot with switched axes
bar = sns.barplot(x="Count", y="affiliated_organization", hue="Victim Type", data=victim_melted, ax=ax)

# Add the legend outside the plot
plt.legend(title='Victim Type', bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)

# Loop over the bars and add text annotation
for p in bar.patches:
    width = p.get_width()  # get the width of each bar
    x, y = p.get_xy()  # get the bottom left coordinates
    if width > 0:
        bar.annotate(f'{int(width)}',  # The label for this bar
                     (x + width, y + p.get_height() / 2),  # The X and Y location of the label
                     ha='left',  # Center the label horizontally
                     va='center',  # Center the label vertically
                     weight='bold') 

# Set the labels and title of the plot
ax.set_xlabel('Victim Count', fontsize=12)
ax.set_ylabel('Affiliated Organization', fontsize=12)
ax.set_title('Victim Counts by Affiliated Organizations (2018-2022)', fontsize=16, weight='bold')

# Show the plot
plt.tight_layout()
plt.show()


# In[29]:


import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Assuming 'total_query' and 'cnn' are defined earlier in your code.
victim_query = pd.read_sql_query(total_query, cnn)

# Melt the DataFrame for use with seaborn's barplot
victim_melted = victim_query.melt(id_vars=['affiliated_organization'], 
                                  var_name='Victim Type', 
                                  value_name='Count')

# Set the aesthetic style of the plots
sns.set_theme(style="darkgrid")

# Initialize the matplotlib figure
f, ax = plt.subplots(figsize=(12, 6))

# Create the barplot with switched axes
bar = sns.barplot(x="affiliated_organization", y="Count", hue="Victim Type", data=victim_melted, ax=ax)

# Add the legend outside the plot
plt.legend(title='Victim Type', bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)

# Loop over the bars and add text annotation
for p in bar.patches:
    height = p.get_height()  # get the height of each bar
    x, y = p.get_xy()  # get the bottom left coordinates
    if height > 0:
        bar.annotate(f'{int(height)}',  # The label for this bar
                     (x + p.get_width() / 2, y + height),  # The X and Y location of the label
                     ha='center',  # Center the label horizontally
                     va='bottom',  # Align the label to the bottom
                     weight='bold') 

# Set the labels and title of the plot
ax.set_xlabel('Affiliated Organization', fontsize=12)
ax.set_ylabel('Victim Count', fontsize=12)
ax.set_title('Victim Counts by Affiliated Organizations (2018-2022)', fontsize=16, weight='bold')

# Show the plot
plt.tight_layout()
plt.show()


# In[28]:


import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Assuming 'total_query' and 'cnn' are defined earlier in your code.
victim_query = pd.read_sql_query(total_query, cnn)

# Melt the DataFrame for use with seaborn's barplot
victim_melted = victim_query.melt(id_vars=['affiliated_organization'], 
                                  var_name='Victim Type', 
                                  value_name='Count')

# Set the aesthetic style of the plots
sns.set_theme(style="darkgrid")

# Initialize the matplotlib figure
f, ax = plt.subplots(figsize=(12, 6))

# Create the barplot with switched axes
bar = sns.barplot(x="affiliated_organization", y="Count", hue="Victim Type", data=victim_melted, ax=ax)

# Add the legend outside the plot
plt.legend(title='Victim Type', bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)

# Loop over the bars and add text annotation
for p in bar.patches:
    height = p.get_height()  # get the height of each bar
    x, y = p.get_xy()  # get the bottom left coordinates
    if height > 0:
        bar.annotate(f'{int(height)}',  # The label for this bar
                     (x + p.get_width() / 2, y + height),  # The X and Y location of the label
                     ha='center',  # Center the label horizontally
                     va='bottom',  # Align the label to the bottom
                     weight='bold') 

# Set the labels and title of the plot
ax.set_xlabel('Affiliated Organization', fontsize=12)
ax.set_ylabel('Victim Count', fontsize=12)
ax.set_title('Victim Counts by Affiliated Organizations (2018-2022)', fontsize=16, weight='bold')

# Show the plot
plt.tight_layout()
plt.show()


# In[60]:


#LOGISTICS USED

#logistic_count= %sql SELECT affiliated_organization,SUM(logistic_lvl1_mp) AS Mail_Postage,SUM(logistic_lvl1_nn) AS Perpetrator,SUM(logistic_lvl1_ve) AS Vehicle FROM GRID_PERPS_ISIS_ALQAIDA GROUP BY affiliated_organization;
total_query= "SELECT affiliated_organization,SUM(logistic_lvl1_ve) AS Vehicle FROM GRID_PERPS_ISIS_ALQAIDA GROUP BY affiliated_organization;"
logistic_query=pd.read_sql_query(total_query,cnn)
logistic_query.head()


# In[24]:


logistic_query = pd.read_sql_query(total_query, cnn)

# Melt the DataFrame to work with Seaborn's barplot
logistic_melted = logistic_query.melt(id_vars=['affiliated_organization'], var_name='Logistic Category', value_name='Count')

# Set the aesthetic style of the plots
sns.set_theme(style="darkgrid")

# Initialize the matplotlib figure
f, ax = plt.subplots(figsize=(10, 6))

# Create a color palette
palette = sns.color_palette("dark", len(logistic_melted['affiliated_organization'].unique()))

# Create the barplot with vertical bars
sns.barplot(

    y="Count", 
    x="Logistic Category", 
    hue="affiliated_organization", 
    data=logistic_melted, 
    palette=palette, 
    ci=None  # No error bars
)

# Annotate each bar with the count
for p in ax.patches:
    ax.annotate(f'{int(p.get_height())}',
                xy=(p.get_x() + p.get_width() / 2, p.get_height()),
                xytext=(0, 3),  # 3 points vertical offset
                textcoords='offset points',
                ha='center', va='bottom',weight='bold',fontsize=12)
ax.set_title('Logistics Counts by Affiliated Organization(2018-2022)', fontsize=16, weight='bold')


# Remove the top and right spines
sns.despine(trim=True)

# Show the plot with a tight layout
plt.tight_layout()
plt.show()


# In[61]:


#casuality_count= %sql select affiliated_organization,incident_year,sum(num_killed) as Killed,sum(num_wounded) as Wounded , sum(num_hostkid) as Kidnapped from GRID_PERPS_ISIS_ALQAIDA group by affiliated_organization,incident_year order by incident_year,affiliated_organization; 
total_query= "select affiliated_organization,incident_year, sum(num_killed) as Killed,sum(num_wounded) as Wounded , sum(num_hostkid) as Kidnapped from GRID_PERPS_ISIS_ALQAIDA group by affiliated_organization,incident_year order by incident_year,affiliated_organization;"
casuality_query=pd.read_sql_query(total_query,cnn)
casuality_query.head()


# In[13]:


casuality_query = pd.read_sql_query(total_query, cnn)

# Set the aesthetic style of the plots
sns.set_theme(style="darkgrid")

# Initialize the matplotlib figure
f, ax = plt.subplots(figsize=(14, 8))

# Convert the 'casuality_query' DataFrame into a "melted" version for easy plotting with seaborn
casuality_melted = casuality_query.melt(id_vars=['affiliated_organization', 'incident_year'], 
                                        var_name='Casuality Type', 
                                        value_name='Count')

# Create a bar plot, with 'Count' split into 'Casuality Type', across 'incident_year'
# Set 'ci' to None to remove error bars
sns.barplot(x='incident_year', y='Count', hue='Casuality Type', data=casuality_melted, 
            palette="deep", ci=None)

# Add a legend and informative axis label
ax.legend(title='Casuality Type', loc="upper right", frameon=True)
ax.set_ylabel("Casuality Count")
ax.set_xlabel("Incident Year")

# Add a meaningful title
ax.set_title('Yearly Analysis of Casualties (2018-2022)', fontsize=20, weight='bold')

# Rotate the x-axis labels for better readability
plt.xticks(rotation=0)

# Add labels on the bars
for p in ax.patches:
    if p.get_height() > 0:  # only add a label to non-zero bars
        ax.annotate(f'{int(p.get_height())}',  # Format the number as an int
                    (p.get_x() + p.get_width() / 2., p.get_height()), 
                    ha = 'center', va = 'center', 
                    xytext = (0, 10), 
                    textcoords = 'offset points',weight='bold',fontsize=12)

# Remove the top and right spines for a cleaner look
sns.despine(left=True, bottom=True)

# Show the plot with a tight layout
plt.tight_layout()
plt.show()


# In[62]:


#COUNTRY ANALYSIS
#country_count= %sql select affiliated_organization,incident_year,country_genc_txt,count(country_genc_txt) as incident_count from GRID_PERPS_ISIS_ALQAIDA group by affiliated_organization,incident_year,country_genc_txt  order by incident_year asc,affiliated_organization,incident_count desc;  
total_query= "select affiliated_organization,incident_year,country_genc_txt,count(country_genc_txt) as incident_count from GRID_PERPS_ISIS_ALQAIDA group by affiliated_organization,incident_year,country_genc_txt  order by incident_year asc,affiliated_organization,incident_count desc;"
country_query=pd.read_sql_query(total_query,cnn)
country_query.head()


# In[63]:


#CLAIMED ATTACKED
#claimed_count= %sql SELECT affiliated_organization, incident_year, SUM(claimed) as claimed_attacks FROM GRID_PERPS_ISIS_ALQAIDA GROUP BY affiliated_organization, incident_year ORDER BY affiliated_organization,incident_year,claimed_attacks DESC;
total_query= "SELECT affiliated_organization, incident_year,SUM(claimed) as claimed_attacks FROM GRID_PERPS_ISIS_ALQAIDA GROUP BY affiliated_organization, incident_year ORDER BY affiliated_organization,incident_year,claimed_attacks DESC;"
claimed_query=pd.read_sql_query(total_query,cnn)
claimed_query.head()


# In[126]:


import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

# Assuming 'claimed_query' is already your DataFrame from the SQL query

# Set the aesthetic style of the plots
sns.set_theme(style="darkgrid")

# Initialize the matplotlib figure
f, ax = plt.subplots(figsize=(15, 10))

# Sort the data for better visualization
claimed_query_sorted = claimed_query.sort_values(by=['claimed_attacks'], ascending=False)

# Create the barplot
sns.barplot(
    x="claimed_attacks", 
    y="affiliated_organization", 
    hue="incident_year", 
    data=claimed_query_sorted, 
    palette="muted"
)

# Customize the appearance of the plot
ax.set_title('Yearly analysis of Claimed Attacks(2018-2022)', fontsize=20)
ax.set_xlabel('Number of Claimed Attacks', fontsize=14)
ax.set_ylabel('Affiliated Organization', fontsize=14)

# Move the legend to an appropriate position
ax.legend(title='Incident Year', bbox_to_anchor=(1.05, 1), loc='upper left')

# Annotate the bars with the count of claimed attacks
for p in ax.patches:
    width = p.get_width()
    ax.text(
        width + 7,       # Set the text at 3 units to the right of the bar
        p.get_y() + p.get_height() / 2, # Set the text at the midpoint of the bar height
        '{:1.0f}'.format(width), # Format the number as a decimal
        ha="center", 
        va="center",
        weight='bold',
        fontsize=15
    )

# Display the plot
plt.tight_layout()
plt.show()


# In[107]:


import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

# Assuming 'claimed_query' is your DataFrame from the SQL query

# Ensure the incident_year column is of integer type
claimed_query['incident_year'] = claimed_query['incident_year'].astype(int)

# Filter the DataFrame for the years 2018 through 2022
filtered_data = claimed_query[claimed_query['incident_year'].isin([2018, 2019, 2020, 2021, 2022])]

# Set the aesthetic style of the plots
sns.set_theme(style="darkgrid")

# Create a new figure
plt.figure(figsize=(10, 6))

# Plot each organization's claimed attacks per year as a separate line with markers
sns.lineplot(
    x='incident_year', 
    y='claimed_attacks', 
    hue='affiliated_organization', 
    style='affiliated_organization', 
    markers=True, 
    data=filtered_data,
    palette='tab10', # This is a good qualitative palette for distinct colors
    linewidth=2.5
)

# Customize the appearance of the plot
plt.title('Yearly Analysis of Claimed Attacks as per Organization (2018-2022)', fontsize=20)
plt.xlabel('Incident Year', fontsize=14)
plt.ylabel('Number of Claimed Attacks', fontsize=14)

# Set x-ticks to only show the years as integers
plt.xticks(filtered_data['incident_year'].unique())

# Improve the legend
plt.legend(title='Affiliated Organization', bbox_to_anchor=(1.05, 1), loc='upper left')
for i in range(len(claimed_query)):
    plt.text(
        claimed_query['incident_year'][i], 
        claimed_query['claimed_attacks'][i] + 0.5, # Slightly above the point
        f"{claimed_query['claimed_attacks'][i]:.0f}",
        horizontalalignment='center',
        size='large',
        color='black'
    )

# Show the plot with a tight layout
plt.tight_layout()
plt.show()


# In[64]:


#Regional analysis
#total_region= %sql select region_txt, count(region_txt) as Region_count  from GRID_PERPS_ISIS_ALQAIDA group by affiliated_organization,incident_year,region_txt  order by incident_year,affiliated_organization,Region_count desc;
total_query= "select region_txt, count(region_txt) as Region_count from GRID_PERPS_ISIS_ALQAIDA group by region_txt order by Region_count desc;"
total_region_query=pd.read_sql_query(total_query,cnn)
total_region_query.head()


# In[20]:


import seaborn as sns
import matplotlib.pyplot as plt

# Assuming 'total_region_query' is a DataFrame that contains the data.
sns.set_theme(style="darkgrid")

# Create a bar plot
plt.figure(figsize=(12, 7))
barplot = sns.barplot(data=total_region_query, x='region_txt', y='Region_count', ci=None)
#sns.set_theme(style="darkgrid")

# Add labels to each bar without decimal
for p in barplot.patches:
    barplot.annotate(f'{int(p.get_height())}',  # Remove the decimal by converting to int
                     (p.get_x() + p.get_width() / 2., p.get_height()),
                     ha = 'center', va = 'center',
                     xytext = (0, 9),
                     textcoords = 'offset points',weight='bold')

# Set the labels and title
plt.xlabel('Region')
plt.ylabel('Incident Count')
plt.title('Region wise Incident Count(2018-2022)')

# Improve layout
plt.xticks(rotation=0)  # Rotate the x-axis labels for better readability if needed
plt.tight_layout()  # Adjust the layout
plt.grid(True)
# Show the plot
plt.show()


# In[65]:


#total_region= %sql select affiliated_organization,incident_year,region_txt, count(region_txt) as Region_count  from GRID_PERPS_ISIS_ALQAIDA group by incident_year,region_txt  order by incident_year,Region_count desc;
total_query= "select affiliated_organization,incident_year,region_txt, count(region_txt) as Region_count from GRID_PERPS_ISIS_ALQAIDA group by incident_year,region_txt order by incident_year,Region_count desc;"
total_region_query=pd.read_sql_query(total_query,cnn)
total_region_query.head()


# In[186]:


get_ipython().system('pip install squarify')


# In[66]:


#country_count= %sql select affiliated_organization,incident_year,country_genc_txt,count(country_genc_txt) as incident_count from GRID_PERPS_ISIS_ALQAIDA group by affiliated_organization,incident_year,country_genc_txt  order by incident_year asc,affiliated_organization,incident_count desc;  
total_query= "select affiliated_organization,incident_year,country_genc_txt,count(country_genc_txt) as incident_count from GRID_PERPS_ISIS_ALQAIDA group by affiliated_organization,incident_year,country_genc_txt  order by incident_year asc,affiliated_organization,incident_count desc;"
country_query=pd.read_sql_query(total_query,cnn)
country_query.head()


# In[33]:


get_ipython().system('pip install pycountry')

import pycountry
import pandas as pd

# Assuming you have already executed your SQL query and have the 'country_query' DataFrame
# Your existing code for fetching data from SQL database
# ...

def get_country_code(country_name):
    try:
        return pycountry.countries.lookup(country_name).alpha_2
    except LookupError:
        # If the country name is not found in the pycountry database, return None or some default value
        return None

# Add a new column for country codes to your DataFrame
country_query['country_code'] = country_query['country_genc_txt'].apply(get_country_code)

# Display the DataFrame with the new column
print(country_query.head())

# In[35]:


get_ipython().system('pip install pandas plotly')


# In[ ]:





# In[25]:


# Define bins and labels for incident_count
bins = [0, 10, 50, 100, 500, np.inf]
labels = ['0-10', '11-50', '51-100', '101-500', '500+']
country_query['incident_bin'] = pd.cut(country_query['incident_count'], bins=bins, labels=labels, include_lowest=True)


# In[26]:


# Check for missing values in key columns
print(country_query[['affiliated_organization', 'incident_year', 'country_genc_txt', 'incident_count']].isnull().sum())


# In[67]:


#country_count= %sql select country_genc_txt,count(country_genc_txt) as incident_count from GRID_PERPS_ISIS_ALQAIDA group by country_genc_txt  order by incident_count desc;  
total_query= "select country_genc_txt,count(country_genc_txt) as incident_count from GRID_PERPS_ISIS_ALQAIDA group by country_genc_txt  order by incident_count desc;"
country_query=pd.read_sql_query(total_query,cnn)
country_query.head()


# In[11]:


get_ipython().system('pip install geopy')
get_ipython().system('pip install folium')

import pandas as pd
import folium


# In[41]:


import pandas as pd
import geopandas as gpd
import plotly.express as px

# Assuming 'country_query' is your DataFrame from the SQL query
# Aggregate incident counts per country
aggregated_data = country_query.groupby('country_genc_txt')['incident_count'].sum().reset_index()

# Convert country names to uppercase for consistent matching
aggregated_data['country_genc_txt'] = aggregated_data['country_genc_txt'].str.upper()

# Load world geometries and convert country names to uppercase for matching
world = gpd.read_file(gpd.datasets.get_path('naturalearth_lowres'))
world['name'] = world['name'].str.upper()

# Merge world geometries with aggregated data
merged = world.merge(aggregated_data, how="left", left_on='name', right_on='country_genc_txt')

# Calculate centroids for latitude and longitude
merged['centroid'] = merged.geometry.centroid
merged['centroid_lat'] = merged['centroid'].y
merged['centroid_lon'] = merged['centroid'].x

# Fill missing values with 0 for 'incident_count'
merged['incident_count'] = merged['incident_count'].fillna(0)

# Bin the incident counts into categories
bins = [0, 100, 200, 300, 400, float('inf')]
labels = ['1-100', '101-200', '201-300', '301-400', '400+']
merged['incident_count_category'] = pd.cut(merged['incident_count'], bins=bins, labels=labels, right=False)

# Define color categories and corresponding colors
color_palette = ['blue', 'skyblue', 'green', 'purple', 'red']

# Create a scatter_geo map with bubbles colored by incident count categories
fig = px.scatter_geo(merged,
                     lat='centroid_lat',
                     lon='centroid_lon',
                     size='incident_count',
                     color='incident_count_category',
                     color_discrete_map=dict(zip(labels, color_palette)),
                     hover_name='name',
                     size_max=30,
                    category_orders={'incident_count_category':['1-100','101-200','201-300','301-400','400+']})

# Customize the layout to show only country outlines
fig.update_geos(
    visible=False,  # Hide the default basemap
    showcountries=True,  # Show country outlines
    countrycolor="Black"  # Country boundary color
)

# Customize the layout
fig.update_layout(
    geo=dict(
        bgcolor='rgba(255,255,255,255)',
        lakecolor='rgba(255,255,255,255)',
        landcolor='rgba(255,255,255,255)'
    ),
    margin={"r": 0, "t": 0, "l": 0, "b": 0},
    legend=dict(
        title=dict(text='Incident Count'),
        #traceorder='reversed',  # Reverse the order of legend items
    )
)

# Show the figure
fig.show()


# In[25]:


total_query = """
SELECT 
    affiliated_organization,
    SUM(logistic_lvl2_ve_03) as "Civilian vehicle",
    SUM(logistic_lvl2_ve_04) as "Military Vehicle",
    SUM(logistic_lvl2_ve_05) as "Military Armored Vehicle",
    SUM(logistic_lvl2_ve_06) as "Improvised Armored",
    SUM(logistic_lvl2_ve_08) as "Drone",
    SUM(logistic_lvl2_ve_09) as "Public Transport"
FROM 
    GRID_PERPS_ISIS_ALQAIDA 
GROUP BY 
    affiliated_organization;
"""

# Assuming 'cnn' is your database connection
logistic_query = pd.read_sql_query(total_query, cnn)
logistic_query.head()


# In[26]:


import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Assuming 'logistic_query' contains the result of your SQL query
# Melt the DataFrame to work with seaborn's barplot
melted_df = logistic_query.melt(id_vars=['affiliated_organization'], 
                                var_name='Vehicle Type', 
                                value_name='Logistic Count')

# Set the aesthetic style of the plots
sns.set_theme(style="darkgrid")

# Initialize the matplotlib figure
f, ax = plt.subplots(figsize=(15, 10))

# Create the barplot
barplot = sns.barplot(x='Logistic Count', y='affiliated_organization', hue='Vehicle Type', data=melted_df)

# Add labels to each bar
for p in barplot.patches:
    width = p.get_width()  # Get the width (count) of each bar
    barplot.text(width + 1,  # X position for label (add a small margin)
                 p.get_y() + p.get_height() / 2,  # Y position (center of the bar)
                 f'{int(width)}',  # Label (rounded to nearest integer)
                 va='center')  # Vertical alignment

# Set the title and labels of the plot
ax.set_title('Logistics Count by Affiliated Organization (2018-2022)', fontsize=16)
ax.set_xlabel('Logistic Count', fontsize=12)
ax.set_ylabel('Affiliated Organization', fontsize=12)

# Show the plot
plt.grid(True)
plt.tight_layout()
plt.show()


# In[27]:


import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Assuming 'logistic_query' contains the result of your SQL query
# Melt the DataFrame to work with seaborn's barplot
melted_df = logistic_query.melt(id_vars=['affiliated_organization'], 
                                var_name='Vehicle Type', 
                                value_name='Logistic Count')

# Set the aesthetic style of the plots
sns.set_theme(style="darkgrid")

# Initialize the matplotlib figure
f, ax = plt.subplots(figsize=(15, 10))

# Create the barplot with x and y swapped
barplot = sns.barplot(x='affiliated_organization', y='Logistic Count', hue='Vehicle Type', data=melted_df)

# Add labels to each bar
for p in barplot.patches:
    height = p.get_height()  # Get the height (count) of each bar
    barplot.text(p.get_x() + p.get_width() / 2,  # X position (center of the bar)
                 height + 1,  # Y position for label (add a small margin)
                 f'{int(height)}',  # Label (rounded to nearest integer)
                 ha='center')  # Horizontal alignment

# Set the title and labels of the plot
ax.set_title('Logistics Count by Affiliated Organization (2018-2022)', fontsize=16)
ax.set_xlabel('Affiliated Organization', fontsize=12)
ax.set_ylabel('Logistic Count', fontsize=12)

# Show the plot
plt.grid(True)
plt.tight_layout()
plt.show()

